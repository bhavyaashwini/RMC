export class Student {
    _id?: String;
    student_name?: any;
    student_email?: any;
    section?: String;
    subjects?: Array<string>;
    dob?: Date;
    gender?: String;
    id?: string;
   
 }
  // export class MessageTemplate {
  //     name?: string;
  //     template_id?:any;
  // }
  export class User {
    user_name?: string;
    password?:any;
  }