export class Bookingstatus {
    role_name:any;
    name:any;
}
