export class Optionbyrating {
    id?:any;  
    name?:string;
    star_id?: any; 
    
}
