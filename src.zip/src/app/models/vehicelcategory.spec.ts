import { Vehicelcategory } from './vehicelcategory';

describe('Vehicelcategory', () => {
  it('should create an instance', () => {
    expect(new Vehicelcategory()).toBeTruthy();
  });
});
