export class Messagetemplate {
    name?:any;
    template_id?: any;
    id?:any;
    is_active?:boolean;
    message_template_id?: any;
    message_template:any;
}
