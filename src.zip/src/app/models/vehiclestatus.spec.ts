import { Vehiclestatus } from './vehiclestatus';

describe('Vehiclestatus', () => {
  it('should create an instance', () => {
    expect(new Vehiclestatus()).toBeTruthy();
  });
});
