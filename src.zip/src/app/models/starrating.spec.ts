import { Starrating } from './starrating';

describe('Starrating', () => {
  it('should create an instance', () => {
    expect(new Starrating()).toBeTruthy();
  });
});
