export class Vehicelcategory {
}
