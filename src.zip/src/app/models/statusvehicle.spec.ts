import { Statusvehicle } from './statusvehicle';

describe('Statusvehicle', () => {
  it('should create an instance', () => {
    expect(new Statusvehicle()).toBeTruthy();
  });
});
