export class Statusvehicle {
    status_name?:any;
    name?:any;
}
