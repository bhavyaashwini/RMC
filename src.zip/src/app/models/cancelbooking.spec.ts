import { Cancelbooking } from './cancelbooking';

describe('Cancelbooking', () => {
  it('should create an instance', () => {
    expect(new Cancelbooking()).toBeTruthy();
  });
});
