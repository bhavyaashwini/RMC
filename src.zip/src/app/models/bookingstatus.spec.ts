import { Bookingstatus } from './bookingstatus';

describe('Bookingstatus', () => {
  it('should create an instance', () => {
    expect(new Bookingstatus()).toBeTruthy();
  });
});
