import { Optionbyrating } from './optionbyrating';

describe('Optionbyrating', () => {
  it('should create an instance', () => {
    expect(new Optionbyrating()).toBeTruthy();
  });
});
