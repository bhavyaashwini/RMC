export class Userrole {
    role_name?:any;
}
