export class Cancelbooking {
    id?:any;
    name?:any;
}
