export class Starrating {
    name?:any;
    value?:any;
    id?:any;
}
