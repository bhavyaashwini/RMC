import { Messagetemplate } from './messagetemplate';

describe('Messagetemplate', () => {
  it('should create an instance', () => {
    expect(new Messagetemplate()).toBeTruthy();
  });
});
