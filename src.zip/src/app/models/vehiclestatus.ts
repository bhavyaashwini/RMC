export class Vehiclestatus {
}
