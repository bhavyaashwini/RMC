import { Userrole } from './userrole';

describe('Userrole', () => {
  it('should create an instance', () => {
    expect(new Userrole()).toBeTruthy();
  });
});
