import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bookingstatusedit',
  templateUrl: './bookingstatusedit.component.html',
  styleUrls: ['./bookingstatusedit.component.css']
})
export class BookingstatuseditComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
