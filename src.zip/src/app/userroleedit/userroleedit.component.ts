import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-userroleedit',
  templateUrl: './userroleedit.component.html',
  styleUrls: ['./userroleedit.component.css']
})
export class UserroleeditComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
