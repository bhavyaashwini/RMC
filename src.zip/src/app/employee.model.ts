export class Employee {
    id?: any;
    empid: any;
    phone: any;
    email?: string;
    firstName?: string;
    lastName?: string;
    
}
