import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vehiclecategoryedit',
  templateUrl: './vehiclecategoryedit.component.html',
  styleUrls: ['./vehiclecategoryedit.component.css']
})
export class VehiclecategoryeditComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
