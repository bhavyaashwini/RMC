import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-starratingedit',
  templateUrl: './starratingedit.component.html',
  styleUrls: ['./starratingedit.component.css']
})
export class StarratingeditComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
