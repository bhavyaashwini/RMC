import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vehiclestatusedit',
  templateUrl: './vehiclestatusedit.component.html',
  styleUrls: ['./vehiclestatusedit.component.css']
})
export class VehiclestatuseditComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
