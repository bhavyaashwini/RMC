import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-banneredit',
  templateUrl: './banneredit.component.html',
  styleUrls: ['./banneredit.component.css']
})
export class BannereditComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
